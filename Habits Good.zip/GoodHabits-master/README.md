# GoodHabits

A minimal app to track your progress of new habits!


<img src="https://user-images.githubusercontent.com/34299693/119901816-08311000-bf64-11eb-8d07-dff440af016b.jpg" height="400"/> <img src="https://user-images.githubusercontent.com/34299693/119901829-0b2c0080-bf64-11eb-8e32-dd2a17b684e1.jpg" height="400"/> <img src="https://user-images.githubusercontent.com/34299693/119901841-0ebf8780-bf64-11eb-8619-6abc13ced38d.jpg" height="400"/>

<img src="https://user-images.githubusercontent.com/34299693/119901855-11ba7800-bf64-11eb-927b-cecfda9a5b30.jpg" height="400"/> <img src="https://user-images.githubusercontent.com/34299693/119901861-14b56880-bf64-11eb-840a-ffa19e7a33c3.jpg" height="400"/> <img src="https://user-images.githubusercontent.com/34299693/119901872-17b05900-bf64-11eb-8519-20180b05321b.jpg" height="400"/>

